package com.esdy.builder;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/** Minimal binary-XML (AndroidManifest.xml) string-pool editor. */
final class Axml {

    private Axml() { }

    static byte[] patch(byte[] in, String[][] repl) {

        ByteBuffer b = ByteBuffer.wrap(in).order(ByteOrder.LITTLE_ENDIAN);

        int fileHeader = b.getShort(2) & 0xFFFF;
        int pos = fileHeader;

        if ((b.getShort(pos) & 0xFFFF) != 0x0001) {
            throw new IllegalStateException("Manifest string pool not found");
        }

        int spHeader = b.getShort(pos + 2) & 0xFFFF;
        int spSize = b.getInt(pos + 4);
        int strCount = b.getInt(pos + 8);
        int styleCount = b.getInt(pos + 12);
        int flags = b.getInt(pos + 16);
        int strStart = b.getInt(pos + 20);
        int styStart = b.getInt(pos + 24);
        boolean utf8 = (flags & 0x100) != 0;

        int offTable = pos + spHeader;

        String[] strs = new String[strCount];

        for (int i = 0; i < strCount; i++) {
            int p = pos + strStart + b.getInt(offTable + 4 * i);
            strs[i] = utf8 ? readUtf8(in, p) : readUtf16(b, p);
            for (String[] r : repl) {
                if (strs[i].equals(r[0])) {
                    strs[i] = r[1];
                }
            }
        }

        byte[] styleOffsets = new byte[0];
        byte[] styleData = new byte[0];

        if (styleCount > 0) {
            styleOffsets = new byte[4 * styleCount];
            System.arraycopy(in, offTable + 4 * strCount, styleOffsets, 0, styleOffsets.length);
            int len = spSize - styStart;
            styleData = new byte[len];
            System.arraycopy(in, pos + styStart, styleData, 0, len);
        }

        ByteArrayOutputStream sd = new ByteArrayOutputStream();
        int[] offs = new int[strCount];

        for (int i = 0; i < strCount; i++) {
            offs[i] = sd.size();
            if (utf8) writeUtf8(sd, strs[i]);
            else writeUtf16(sd, strs[i]);
        }

        while (sd.size() % 4 != 0) sd.write(0);

        int newStrStart = spHeader + 4 * strCount + 4 * styleCount;
        int newStyStart = styleCount > 0 ? newStrStart + sd.size() : 0;
        int newSpSize = newStrStart + sd.size() + styleData.length;

        int restStart = pos + spSize;
        int restLen = in.length - restStart;

        ByteBuffer o = ByteBuffer
                .allocate(fileHeader + newSpSize + restLen)
                .order(ByteOrder.LITTLE_ENDIAN);

        o.put(in, 0, fileHeader);
        o.putInt(4, fileHeader + newSpSize + restLen);

        o.position(fileHeader);
        o.putShort((short) 0x0001);
        o.putShort((short) spHeader);
        o.putInt(newSpSize);
        o.putInt(strCount);
        o.putInt(styleCount);
        o.putInt(flags & ~0x1);
        o.putInt(newStrStart);
        o.putInt(newStyStart);

        /* any extra header bytes beyond 28 */
        for (int i = 28; i < spHeader; i++) o.put(in[pos + i]);

        for (int i = 0; i < strCount; i++) o.putInt(offs[i]);
        o.put(styleOffsets);
        o.put(sd.toByteArray());
        o.put(styleData);
        o.put(in, restStart, restLen);

        return o.array();
    }

    private static String readUtf8(byte[] d, int p) {
        int l = d[p++] & 0xFF;
        if ((l & 0x80) != 0) p++;               /* 2-byte char length */
        int bl = d[p++] & 0xFF;
        if ((bl & 0x80) != 0) {
            bl = ((bl & 0x7F) << 8) | (d[p++] & 0xFF);
        }
        return new String(d, p, bl, StandardCharsets.UTF_8);
    }

    private static String readUtf16(ByteBuffer b, int p) {
        int l = b.getShort(p) & 0xFFFF;
        p += 2;
        if ((l & 0x8000) != 0) {
            l = ((l & 0x7FFF) << 16) | (b.getShort(p) & 0xFFFF);
            p += 2;
        }
        char[] c = new char[l];
        for (int i = 0; i < l; i++) c[i] = (char) (b.getShort(p + 2 * i) & 0xFFFF);
        return new String(c);
    }

    private static void writeLen8(ByteArrayOutputStream o, int len) {
        if (len > 0x7F) {
            o.write((len >> 8) | 0x80);
            o.write(len & 0xFF);
        } else {
            o.write(len);
        }
    }

    private static void writeUtf8(ByteArrayOutputStream o, String s) {
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
        writeLen8(o, s.length());
        writeLen8(o, bytes.length);
        o.write(bytes, 0, bytes.length);
        o.write(0);
    }

    private static void writeUtf16(ByteArrayOutputStream o, String s) {
        int len = s.length();
        if (len > 0x7FFF) {
            int hi = (len >> 16) | 0x8000;
            o.write(hi & 0xFF); o.write(hi >> 8);
            o.write(len & 0xFF); o.write((len >> 8) & 0xFF);
        } else {
            o.write(len & 0xFF); o.write(len >> 8);
        }
        for (int i = 0; i < len; i++) {
            char c = s.charAt(i);
            o.write(c & 0xFF);
            o.write(c >> 8);
        }
        o.write(0); o.write(0);
    }
}
