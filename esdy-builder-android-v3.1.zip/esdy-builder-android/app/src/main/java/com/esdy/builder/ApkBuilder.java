package com.esdy.builder;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import com.android.apksig.ApkSigner;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.regex.Pattern;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.security.auth.x500.X500Principal;

final class ApkBuilder {

    private static final String OLD_PACKAGE = "com.esdy.shell";
    private static final String OLD_LABEL = "ESDYLABELPLACEHOLDER";
    private static final String OLD_VERSION = "ESDYVERSIONPLACEHOLDER";
    private static final String KEY_ALIAS = "esdy_app_signing";
    private static final Pattern PKG =
            Pattern.compile("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$");
    /* The shell template contains exactly ONE png resource (the launcher icon).
       Release builds may shorten its path (e.g. res/aB.png), so we match any png
       under res/ and confirm it really is a PNG by its header. */
    private static final Pattern ICON = Pattern.compile("^res/.*\\.png$");
    private static final byte[] PNG_MAGIC = {(byte) 0x89, 'P', 'N', 'G'};

    private ApkBuilder() { }

    interface Progress { void step(int pct, String msg); }

    static File build(Context ctx, byte[] html, String configJson, byte[] iconPng,
                      String pkg, String label, String version, Progress pr) throws Exception {

        if (!PKG.matcher(pkg).matches()) {
            throw new IllegalArgumentException("Invalid package ID: " + pkg);
        }

        pr.step(5, "Preparing template…");

        File shell = new File(ctx.getCacheDir(), "shell.apk");
        try (InputStream in = ctx.getAssets().open("shell.apk");
             OutputStream out = new FileOutputStream(shell)) {
            copy(in, out);
        }

        pr.step(20, "Editing manifest, icon and app files…");

        File unsigned = new File(ctx.getCacheDir(), "unsigned.apk");
        rewrite(shell, unsigned, html, configJson, iconPng, pkg, label, version);

        pr.step(50, "Signing APK…");

        File signed = new File(ctx.getCacheDir(), "signed.apk");
        sign(unsigned, signed);

        //noinspection ResultOfMethodCallIgnored
        shell.delete();
        //noinspection ResultOfMethodCallIgnored
        unsigned.delete();

        pr.step(80, "Finalizing…");

        return signed;
    }

    private static void rewrite(File src, File dst, byte[] html, String cfg, byte[] icon,
                                String pkg, String label, String version) throws Exception {

        String[][] repl = new String[][]{
                {OLD_PACKAGE, pkg},
                {OLD_LABEL, label},
                {OLD_VERSION, version}
        };

        try (ZipFile zf = new ZipFile(src);
             CountingOut co = new CountingOut(new BufferedOutputStream(new FileOutputStream(dst)));
             ZipOutputStream zo = new ZipOutputStream(co)) {

            Enumeration<? extends ZipEntry> en = zf.entries();
            int iconReplaced = 0;

            while (en.hasMoreElements()) {

                ZipEntry e = en.nextElement();
                String n = e.getName();

                if (e.isDirectory() || n.startsWith("META-INF/")) continue;

                byte[] data;
                try (InputStream in = zf.getInputStream(e)) {
                    data = readAll(in);
                }

                if (n.equals("AndroidManifest.xml")) {
                    data = Axml.patch(data, repl);
                } else if (n.equals("assets/www/index.html")) {
                    data = html;
                } else if (n.equals("assets/config.json")) {
                    data = cfg.getBytes(StandardCharsets.UTF_8);
                } else if (icon != null && icon.length > 0
                        && ICON.matcher(n).matches() && isPng(data)) {
                    data = icon;
                    iconReplaced++;
                }

                boolean store = n.equals("resources.arsc") || e.getMethod() == ZipEntry.STORED;

                ZipEntry ne = new ZipEntry(n);

                if (store) {
                    CRC32 crc = new CRC32();
                    crc.update(data);
                    ne.setMethod(ZipEntry.STORED);
                    ne.setSize(data.length);
                    ne.setCompressedSize(data.length);
                    ne.setCrc(crc.getValue());

                    int base = (int) ((co.count + 30 + n.getBytes(StandardCharsets.UTF_8).length) % 4);
                    if (base != 0) {
                        int pad = 4 - base;
                        byte[] extra = new byte[4 + pad];
                        extra[0] = 0x35;
                        extra[1] = (byte) 0xD9;
                        extra[2] = (byte) pad;
                        extra[3] = 0;
                        ne.setExtra(extra);
                    }
                } else {
                    ne.setMethod(ZipEntry.DEFLATED);
                }

                zo.putNextEntry(ne);
                zo.write(data);
                zo.closeEntry();
            }

            if (icon != null && icon.length > 0 && iconReplaced == 0) {
                throw new IOException("App icon could not be applied to the template");
            }
        }
    }

    private static boolean isPng(byte[] d) {
        if (d == null || d.length < 4) return false;
        for (int i = 0; i < 4; i++) if (d[i] != PNG_MAGIC[i]) return false;
        return true;
    }

    private static void sign(File in, File out) throws Exception {

        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);

        if (!ks.containsAlias(KEY_ALIAS)) {
            KeyPairGenerator g = KeyPairGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");

            g.initialize(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_SIGN)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .setKeySize(2048)
                    .setCertificateSubject(new X500Principal("CN=ESDY Builder"))
                    .setCertificateNotBefore(new Date(System.currentTimeMillis() - 86400000L))
                    .setCertificateNotAfter(new Date(4102444800000L))
                    .build());

            g.generateKeyPair();
        }

        PrivateKey key = (PrivateKey) ks.getKey(KEY_ALIAS, null);
        X509Certificate cert = (X509Certificate) ks.getCertificate(KEY_ALIAS);

        ApkSigner.SignerConfig sc =
                new ApkSigner.SignerConfig.Builder("esdy", key, Collections.singletonList(cert))
                        .build();

        if (out.exists()) //noinspection ResultOfMethodCallIgnored
            out.delete();

        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in)
                .setOutputApk(out)
                .setMinSdkVersion(29)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(false)
                .setV4SigningEnabled(false)
                .build()
                .sign();
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        copy(in, o);
        return o.toByteArray();
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }

    private static final class CountingOut extends FilterOutputStream {
        long count = 0;

        CountingOut(OutputStream o) { super(o); }

        @Override public void write(int b) throws IOException { out.write(b); count++; }

        @Override public void write(byte[] b, int off, int len) throws IOException {
            out.write(b, off, len);
            count += len;
        }
    }
}
