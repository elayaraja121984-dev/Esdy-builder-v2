package com.esdy.builder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.widget.ImageView;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.json.JSONObject;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 1;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private ImageView splash;
    private long splashStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /* Android 12+: drop the system splash instantly; our own splash is already on screen */
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                getSplashScreen().setOnExitAnimationListener(v -> v.remove());
            } catch (Throwable ignored) { }
        }

        web = new WebView(this);

        // Android 15 / API 35 enforces edge-to-edge: keep content clear of system bars.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF07111F);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        showSplash();

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars()
                                | WindowInsets.Type.displayCutout()
                                | WindowInsets.Type.ime());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            });
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                /* backup only: the page normally calls AndroidBridge.appReady() once painted */
                ui.postDelayed(MainActivity.this::hideSplashWhenSeen, 1500);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;

                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");

                try {
                    startActivityForResult(Intent.createChooser(i, "Choose file"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("OK", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("OK", (d, w) -> r.confirm())
                        .setNegativeButton("Cancel", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);

        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    /* ---- opening splash screen (ESDY wordmark) ---- */
    private void showSplash() {
        splash = new ImageView(this);
        splash.setBackgroundColor(Color.WHITE);
        splash.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        splash.setImageResource(R.drawable.esdy_splash);

        ((ViewGroup) getWindow().getDecorView()).addView(splash,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));

        splashStart = SystemClock.uptimeMillis();
        setSplashBars(true);

        /* safety: never block the app longer than 3 s */
        ui.postDelayed(this::hideSplash, 3000);
    }

    /* keep the splash visible for at least ~1 s so the logo is actually seen */
    private void hideSplashWhenSeen() {
        long wait = Math.max(0, 1000 - (SystemClock.uptimeMillis() - splashStart));
        ui.postDelayed(this::hideSplash, wait);
    }

    private void hideSplash() {
        if (splash == null) return;
        final View v = splash;
        splash = null;

        v.animate().alpha(0f).setDuration(280).withEndAction(() -> {
            ViewGroup parent = (ViewGroup) v.getParent();
            if (parent != null) parent.removeView(v);
            setSplashBars(false);
        }).start();
    }

    /* dark status/navigation icons while the white splash is visible */
    private void setSplashBars(boolean light) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light ? mask : 0, mask);
            }
        }
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private static String safeName(String s) {
        String r = s.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
        return r.isEmpty() ? "app" : r;
    }

    private Uri saveToDownloads(String name, String mime, File file) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ESDY");

        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);

        try (InputStream in = new FileInputStream(file);
             OutputStream o = getContentResolver().openOutputStream(uri)) {
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
        }
        return uri;
    }

    private void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
    }

    private class Bridge {

        @JavascriptInterface
        public void buildApk(final String name, final String pkg, final String version,
                             final String htmlB64, final String iconB64, final String cfgJson) {

            new Thread(() -> {
                try {
                    byte[] html = Base64.decode(htmlB64, Base64.DEFAULT);
                    byte[] icon = iconB64 == null || iconB64.isEmpty()
                            ? null : Base64.decode(iconB64, Base64.DEFAULT);

                    File apk = ApkBuilder.build(MainActivity.this, html, cfgJson, icon,
                            pkg, name, version,
                            (pct, msg) -> js("window.esdyApkProgress&&esdyApkProgress("
                                    + pct + "," + JSONObject.quote(msg) + ")"));

                    String fileName = safeName(name) + "-v" + safeName(version) + ".apk";
                    js("window.esdyApkProgress&&esdyApkProgress(90,\"Saving to Downloads…\")");

                    Uri uri = saveToDownloads(fileName,
                            "application/vnd.android.package-archive", apk);

                    final long size = apk.length();

                    //noinspection ResultOfMethodCallIgnored
                    apk.delete();

                    js("esdyApkDone(true," + JSONObject.quote(fileName) + ","
                            + JSONObject.quote(uri.toString()) + "," + size + ")");

                } catch (Throwable t) {
                    String m = t.getClass().getSimpleName() + ": " + t.getMessage();
                    js("esdyApkDone(false," + JSONObject.quote(m) + ",'')");
                }
            }).start();
        }

        @JavascriptInterface
        public void appReady() {
            runOnUiThread(MainActivity.this::hideSplashWhenSeen);
        }

        @JavascriptInterface
        public boolean deleteApk(String uriStr) {
            try {
                return getContentResolver().delete(Uri.parse(uriStr), null, null) > 0;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void shareApk(String uriStr) {
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("application/vnd.android.package-archive");
                i.putExtra(Intent.EXTRA_STREAM, Uri.parse(uriStr));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Share APK"));
            } catch (Exception e) {
                toast("Cannot share: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void installApk(String uriStr) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(Uri.parse(uriStr), "application/vnd.android.package-archive");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("Cannot open APK: " + e.getMessage()
                        + "  (find it in Downloads/ESDY)");
            }
        }

        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);

                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/ESDY");

                Uri uri = getContentResolver()
                        .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);

                try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                    o.write(data);
                }

                toast("Saved: Downloads/ESDY/" + name);

            } catch (Exception e) {
                toast("Save failed: " + e.getMessage());
            }
        }
    }
}
