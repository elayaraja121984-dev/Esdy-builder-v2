package com.esdy.shell;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.GeolocationPermissions;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.local";
    private static final int REQ_FILE = 1;
    private static final int REQ_WEB = 2;
    private static final int REQ_GEO = 3;
    private static final int REQ_NOTIF = 4;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private JSONObject cfg = new JSONObject();
    private final Set<String> allowed = new HashSet<>();

    private PermissionRequest pendingWeb;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeo;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private View splash;
    private long splashStart;

    private boolean enabled(String p) { return allowed.contains(p); }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            cfg = new JSONObject(readAsset("config.json"));
        } catch (Exception ignored) { }

        JSONArray arr = cfg.optJSONArray("permissions");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) allowed.add(arr.optString(i));
        }

        if ("portrait".equals(cfg.optString("orientation"))) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

        int themeColor = Color.parseColor("#101828");
        try {
            themeColor = Color.parseColor(cfg.optString("theme", "#101828"));
        } catch (Exception ignored) { }

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);

        /* Android 15 / API 35: edge-to-edge is enforced - keep content clear of the bars */
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(themeColor);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        /* Android 12+: no extra system-splash animation, our overlay is already showing */
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                getSplashScreen().setOnExitAnimationListener(v -> v.remove());
            } catch (Throwable ignored) { }
        }

        showSplash(root, themeColor);

        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets i = insets.getInsets(
                        WindowInsets.Type.systemBars()
                                | WindowInsets.Type.displayCutout()
                                | WindowInsets.Type.ime());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            });
        } else {
            try {
                getWindow().setStatusBarColor(themeColor);
            } catch (Exception ignored) { }
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(enabled("location"));

        web.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageFinished(WebView v, String url) {
                hideSplashSoon();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();

                if (!HOST.equals(u.getHost())) {
                    /* Internet switch OFF = the app can not reach the network */
                    if (!enabled("internet")) {
                        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked",
                                null, new ByteArrayInputStream(new byte[0]));
                    }
                    return null;
                }

                String path = u.getPath();
                if (path == null || path.equals("/")) path = "/index.html";

                try {
                    InputStream in = getAssets().open("www" + path);
                    return new WebResourceResponse(mime(path), "utf-8", in);
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                            null, new ByteArrayInputStream(new byte[0]));
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (HOST.equals(r.getUrl().getHost())) return false;
                if (!enabled("internet")) {
                    Toast.makeText(MainActivity.this,
                            "Internet access is disabled for this app", Toast.LENGTH_SHORT).show();
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb,
                                             FileChooserParams p) {

                if (!enabled("files")) {
                    cb.onReceiveValue(null);
                    Toast.makeText(MainActivity.this,
                            "File access is disabled for this app", Toast.LENGTH_SHORT).show();
                    return true;
                }

                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose file"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingWeb == request) pendingWeb = null;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin,
                                                           GeolocationPermissions.Callback cb) {
                if (!enabled("location")) {
                    cb.invoke(origin, false, false);
                    return;
                }
                if (has(Manifest.permission.ACCESS_FINE_LOCATION)
                        || has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    cb.invoke(origin, true, false);
                    return;
                }
                pendingGeoOrigin = origin;
                pendingGeo = cb;
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO);
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("OK", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("OK", (d, w) -> r.confirm())
                        .setNegativeButton("Cancel", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }
        });

        /* Notifications: only ask at launch when the builder switched it ON */
        if (enabled("notifications") && Build.VERSION.SDK_INT >= 33
                && !has("android.permission.POST_NOTIFICATIONS")) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
        }

        web.loadUrl("https://" + HOST + "/index.html");
    }

    /* ---- opening splash: app icon on the theme colour, fades out when the page is ready ---- */
    private void showSplash(FrameLayout root, int bg) {
        FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(bg);
        box.setClickable(true);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.app_icon);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int size = (int) (112 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size, Gravity.CENTER);
        box.addView(logo, lp);

        root.addView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        splash = box;
        splashStart = SystemClock.uptimeMillis();

        /* safety: never block the app for more than 3 s */
        ui.postDelayed(this::hideSplash, 3000);
    }

    private void hideSplashSoon() {
        long wait = Math.max(0, 700 - (SystemClock.uptimeMillis() - splashStart));
        ui.postDelayed(this::hideSplash, wait);
    }

    private void hideSplash() {
        if (splash == null) return;
        final View v = splash;
        splash = null;
        v.animate().alpha(0f).setDuration(250).withEndAction(() -> {
            ViewGroup parent = (ViewGroup) v.getParent();
            if (parent != null) parent.removeView(v);
        }).start();
    }

    /* camera / microphone requested by the web page */
    private void handleWebPermission(PermissionRequest request) {

        List<String> grant = new ArrayList<>();
        List<String> sys = new ArrayList<>();

        for (String r : request.getResources()) {

            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && enabled("camera")) {
                if (has(Manifest.permission.CAMERA)) grant.add(r);
                else sys.add(Manifest.permission.CAMERA);
            }

            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && enabled("microphone")) {
                if (has(Manifest.permission.RECORD_AUDIO)) grant.add(r);
                else sys.add(Manifest.permission.RECORD_AUDIO);
            }
        }

        if (!sys.isEmpty()) {
            pendingWeb = request;
            requestPermissions(sys.toArray(new String[0]), REQ_WEB);
            return;
        }

        if (grant.isEmpty()) request.deny();
        else request.grant(grant.toArray(new String[0]));
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);

        if (code == REQ_WEB && pendingWeb != null) {
            PermissionRequest r = pendingWeb;
            pendingWeb = null;

            List<String> grant = new ArrayList<>();
            for (String res : r.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                        && enabled("camera") && has(Manifest.permission.CAMERA)) grant.add(res);
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)
                        && enabled("microphone") && has(Manifest.permission.RECORD_AUDIO)) grant.add(res);
            }

            if (grant.isEmpty()) r.deny();
            else r.grant(grant.toArray(new String[0]));
        }

        if (code == REQ_GEO && pendingGeo != null) {
            boolean ok = has(Manifest.permission.ACCESS_FINE_LOCATION)
                    || has(Manifest.permission.ACCESS_COARSE_LOCATION);
            pendingGeo.invoke(pendingGeoOrigin, ok, false);
            pendingGeo = null;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        if (!hasFocus || !cfg.optBoolean("fullscreen", false)) return;

        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else finish();
    }

    private String readAsset(String name) throws Exception {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toString("UTF-8");
        }
    }

    private static String mime(String p) {
        p = p.toLowerCase();
        if (p.endsWith(".html") || p.endsWith(".htm")) return "text/html";
        if (p.endsWith(".js")) return "text/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }
}
